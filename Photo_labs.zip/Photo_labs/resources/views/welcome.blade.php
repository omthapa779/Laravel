<html>
    <head>
        <link rel="stylesheet" href ="{{asset('CSS/style.css')}}">
    </head>
    <body>
    <h1>{{$name}}, {{$age}}</h1>
    <h2>Hello I am Ashna Shrestha </h2>
<h1>Profile</h1>
</body>
</html>
